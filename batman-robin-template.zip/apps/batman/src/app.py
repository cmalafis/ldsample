print('Hello from Batman!')
