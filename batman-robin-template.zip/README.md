# Batman & Robin Podman App Template

This template helps deploy AI-ready containers with Podman Compose, NVIDIA GPU support, and CI/CD pipelines using GitLab or GitHub.
